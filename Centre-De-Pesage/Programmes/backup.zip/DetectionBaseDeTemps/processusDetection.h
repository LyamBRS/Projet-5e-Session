// Processus Detection.h
#ifndef PROCESSUSDETECTION_H
#define PROCESSUSDETECTION_H



void processusDetection_initialise(void);





#endif